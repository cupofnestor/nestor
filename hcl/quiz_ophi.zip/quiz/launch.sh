#!/bin/bash
/Applications/iCal.app/Contents/MacOS/iCal
echo $1
